
<h1 align="center">🌸 𝙍𝙪𝙗𝙮 𝙃𝙤𝙨𝙝𝙞𝙣𝙤 🌸</h1>

<p align="center">
  <img src="https://files.catbox.moe/atnv7f.gif" alt="Ruby Hoshino Bot Preview" />
</p>


---

## 💫 𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐜𝐢o𝐧 𝐝𝐞𝐥 𝐁𝐨𝐭

<details>
  <summary><b>☁️ 𝐀𝐜𝐥𝐚𝐫𝐚𝐜𝐢o𝐧 𝐥𝐞𝐠𝐚𝐥</b></summary>

> 🚫 **Este proyecto NO está afiliado a WhatsApp ni WhatsApp LLC.**  
> un bot hecho 100% independiente, la base del bot es de Yuki Suou. bot personalizado por **Dioneibi‑rip**.
</details>

---

## 🧩 𝐅𝐮𝐧𝐜𝐢𝐨𝐧𝐞𝐬 𝐝𝐞 𝐑𝐮𝐛𝐲

<details>
  <summary><b>✨ 𝐓𝐨𝐝𝐨 𝐥𝐨 𝐪𝐮𝐞 𝐩𝐮𝐞𝐝𝐞 𝐡𝐚𝐜𝐞𝐫</b></summary>

- 👥 Gestión de grupos (bienvenidas, reglas, etc.)
- 🛡️ Antidelete, antilink, antispam
- 🎉 Mensaje de bienvenida personalizado
- 🎮 Juegos: tictactoe, piedra papel o tijera, etc.
- 🤖 Chatbots: Simsimi y autoresponder AI
- 🎨 Stickers desde imágenes, videos, GIFs o enlaces
- 🔎 Búsquedas rápidas en Google
- 🧙 Juego RPG integrado
- 🎵 Descarga de música y videos desde YouTube
- 🔧 ¡Y muchas otras funciones!

</details>

---

## 🛠️ 𝐈𝐧𝐬𝐭𝐚𝐥𝐚𝐜𝐢o𝐧

### **`🤖 𝐇𝐚𝐳 𝐜𝐥𝐢𝐜𝐤 𝐞𝐧 𝐥𝐚 𝐢𝐦𝐚𝐠𝐞𝐧 𝐩𝐚𝐫𝐚 𝐝𝐞𝐬𝐜𝐚𝐫𝐠𝐚𝐫 𝐭𝐞𝐫𝐦𝐮𝐱 ⏱️`**
<a
href="https://www.mediafire.com/file/llugt4zgj7g3n3u/com.termux_1020.apk/file"><img src="https://qu.ax/finc.jpg" height="125px"></a> 

### 📱 Instalación en **Termux**

<details>
  <summary><b>🔰 Ver comandos de instalación</b></summary>

```bash
termux-setup-storage
```

```bash
apt update && apt upgrade && pkg install -y git nodejs ffmpeg imagemagick yarn
```

```bash
git clone https://github.com/Dioneibi-rip/Ruby-Hoshino-Bot && cd Ruby-Hoshino-Bot
```

```bash
yarn install && npm install && npm update
```

```bash
npm start
```

> Cuando veas: (Y/I/N/O/D/Z) [default=N]  
> Escribe **"y"** y presiona **ENTER**

</details>

---

### **`🖥️ 𝐇𝐚𝐳 𝐜𝐥𝐢𝐜 𝐞𝐧 𝐥𝐚 𝐢𝐦𝐚𝐠𝐞𝐧 𝐩𝐚𝐫𝐚 𝐝𝐞𝐬𝐜𝐚𝐫𝐠𝐚𝐫 𝐜𝐥𝐨𝐮𝐝 𝐬𝐡𝐞𝐥𝐥 ✨`**
<a
href="https://www.mediafire.com/file/bp2l6cci2p30hjv/Cloud+Shell_1.apk/file"><img src="https://qu.ax/iSvfx.webp" height="125px"></a> 

### ☁️ Instalación en **Cloud Shell**

<details>
  <summary><b>🚀 Ver pasos para Cloud Shell</b></summary>

```bash
git clone https://github.com/Dioneibi-rip/Ruby-Hoshino-Bot && cd Ruby-Hoshino-Bot
```

```bash
yarn install && npm install
```

```bash
npm start
```

> ✔️ Asegúrate de que tu Cloud Shell tenga Node.js instalado.
</details>

---

### ♻️ ¿El bot se detuvo?

<details>
  <summary><b>🔁 Cómo reiniciarlo en Termux</b></summary>

```bash
cd Ruby-Hoshino-Bot && npm start
```

</details>

---

### 🧑‍💻 ¿Quieres poner tu número como owner?

<details>
  <summary><b>🔑 edita el archivo y Agrega tu número como Owner</b></summary>

```bash
cd Ruby-Hoshino-Bot
```

```bash
nano settings.js
```

> En el archivo `settings.js`, busca la sección `owner` y coloca tu número ahí.

</details>

---

### **`✦ AKIRAX ✦`**

<a
href="https://home.akirax.net"><img src="https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1748713078525.jpeg" height="125px"></a>

<details>
 <summary><b> ❒ Servidor Akirax</b></summary>

* Dashboard : [`Dash`](https://home.akirax.net)
* Panel : [`Panel`](https://console.akirax.net)
* Canal de WhatsApp : [`Aqui`](https://whatsapp.com/channel/0029VbBCchVDJ6H6prNYfz2z)
* Grupo Oficial : [`Aquí`](https://chat.whatsapp.com/JxSZTFJN9J20TnsH7KsKTA)

</details>

---

## 🌐 𝐄𝐧𝐥𝐚𝐜𝐞𝐬 u𝐭𝐢𝐥𝐞𝐬

<details>
  <summary><b>👥 Grupos Oficiales</b></summary>

- 📢 [Canal Oficial](https://whatsapp.com/channel/0029VakLbM76mYPPFL0IFI3P)
- 🌐 [Comunidad Global](https://chat.whatsapp.com/K2CPrOTksiA36SW6k41yuR)

</details>

<details>
  <summary><b>📞 Contacto</b></summary>

- 📱 WhatsApp: 18294868853
- 📧 Email: dioneibipaselomendes@gmail.com

</details>

---

## 👑 𝐂𝐫𝐞𝐚𝐝𝐨𝐫 𝐝𝐞 𝐑𝐮𝐛𝐲


<a href="https://github.com/Dioneibi-rip"><img src="https://github.com/Dioneibi-rip.png" width="250" height="250" alt="Dioneibi"/></a>

---

### **🌺` Colaboradores Especiales `🌟**
<a href="https://github.com/nevi-dev" style="display:inline-block; text-decoration: none;">
    <img src="https://github.com/nevi-dev.png" width="130" height="130" alt="legna Mini-dev" style="border-radius: 50%;"/>
</a>
<a href="https://github.com/Legna-chan" style="display:inline-block; margin-right: 10px; text-decoration: none;">
    <img src="https://github.com/Legna-chan.png" width="130" height="130" alt="nevi developer" style="border-radius: 50%;"/>
</a>

---
